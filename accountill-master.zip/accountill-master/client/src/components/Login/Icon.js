import React from 'react';

const Icon = () => (
  <svg
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  fill="none"
  stroke="currentColor"
  strokeLinecap="round"
  strokeLinejoin="round"
  strokeWidth="2"
  className="feather feather-lock"
  viewBox="0 0 24 24"
>
  <rect width="18" height="11" x="3" y="11" rx="2" ry="2"></rect>
  <path d="M7 11V7a5 5 0 0110 0v4"></path>
</svg>
);

export default Icon;